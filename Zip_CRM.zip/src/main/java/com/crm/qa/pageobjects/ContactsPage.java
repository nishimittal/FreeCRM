package com.crm.qa.pageobjects;

import java.io.IOException;

import com.crm.qa.generic.BaseLib;

public class ContactsPage extends BaseLib{

	public ContactsPage() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}

}
