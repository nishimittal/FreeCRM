package com.crm.qa.pageobjects;

import java.io.IOException;

import com.crm.qa.generic.BaseLib;

public class HomePage extends BaseLib{

	public HomePage() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}

}
