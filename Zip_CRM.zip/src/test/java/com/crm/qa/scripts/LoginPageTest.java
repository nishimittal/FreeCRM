package com.crm.qa.scripts;


import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import com.crm.qa.generic.BaseLib;
import com.crm.qa.pageobjects.LoginPage;

public class LoginPageTest extends BaseLib{
		

@Test(priority=1)
public void loginPageTitleTest() throws IOException{
	LoginPage loginpage=new LoginPage(driver);
	 loginpage.validateLoginPageTitle(driver);
	 loginpage.validateCRMImage(driver);
	 loginpage.login(prop.getProperty("username"), prop.getProperty("password"),driver);
}

//@Test(priority=2)
//public void loginTest() throws IOException{
//	LoginPage lp=new LoginPage(driver);
//	lp.login(prop.getProperty("username"), prop.getProperty("password"));
//}
} 
